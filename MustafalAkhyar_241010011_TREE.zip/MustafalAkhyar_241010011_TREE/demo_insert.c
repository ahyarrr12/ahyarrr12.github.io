#include "bst.h"

int main(){
    node *root = NULL;

    int data[] = {10, 20, 30, 40, 50, 60, 70};
    int n = sizeof(data) / sizeof(data[0]);

    for (int i = 0; i < n; i++){
        root = insert(root, data[i]);
    }

    printf("\ninorder   : ");
    inorder(root);

    printf("\npreorder  : ");
    preorder(root);

    printf("\npostorder : ");
    postorder(root);

    printf("\n\nhapus node 50\n");
    root = deleteNode(root, 50);

    printf("Inorder setelah delete: ");
    inorder(root);


    return 0;
}
