#ifndef BST_H
#define BST_H

#include <stdio.h>
#include <stdlib.h>

typedef struct node {
    int data;
    struct node *left;
    struct node *right;
} node;


node* createNode(int value);
node* insert(node *root, int value);
node* search(node *root, int value);

void inorder(node *root);
void preorder(node *root);
void postorder(node *root);

node* minValueNode(node *root);
node* maxValueNode(node *root);
node* deleteNode(node *root, int value);

void freeTree(node *root);

#endif
